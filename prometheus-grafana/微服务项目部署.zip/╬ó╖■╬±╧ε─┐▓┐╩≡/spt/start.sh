docker run -d --name spt-admin -p 8401:8401 -v /spt/log:/log spt-admin
docker run -d --name spt-tx-manager -p 8501:8501 -p 8888:8888 -v /spt/log:/log spt-tx-manager
docker run -d --name spt-auth -p 8101:8101 -v /spt/log:/log spt-auth
docker run -d --name spt-server-system -p 8201:8201 -v /spt/log:/log spt-server-system
docker run -d --name spt-server-healthrecord -p 8202:8202 -v /spt/log:/log spt-server-healthrecord
docker run -d --name spt-gateway -p 8301:8301 -v /spt/log:/log spt-gateway
