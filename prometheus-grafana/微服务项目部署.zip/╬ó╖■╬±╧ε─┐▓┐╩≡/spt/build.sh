cd /spt/spt-admin
docker build -t spt-admin .
cd /spt/spt-tx-manager
docker build -t spt-tx-manager .
cd /spt/spt-auth
docker build -t spt-auth .
cd /spt/spt-server-system
docker build -t spt-server-system .
cd /spt/spt-server-healthrecord
docker build -t spt-server-healthrecord .
cd /spt/spt-gateway
docker build -t spt-gateway .
