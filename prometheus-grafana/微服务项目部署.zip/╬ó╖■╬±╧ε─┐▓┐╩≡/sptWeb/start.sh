docker run -d --name spt-cloud-web -p 8045:8045 spt-cloud-web
