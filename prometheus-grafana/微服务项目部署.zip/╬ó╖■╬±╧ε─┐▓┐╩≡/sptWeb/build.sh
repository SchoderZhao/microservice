cd /sptWeb/spt-cloud-web
docker build -t spt-cloud-web .
