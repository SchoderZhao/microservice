docker stop spt-cloud-web
docker rm spt-cloud-web
docker rmi spt-cloud-web